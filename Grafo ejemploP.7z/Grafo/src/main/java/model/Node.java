package model;

public class Node {

    private int valor;
    private Node left;
    private Node right;

    public Node(int valor) {
        this.valor = valor;
        this.left = null;
        this.left = null;
    }

    public Node getLeft() {
        return left;
    }

    public void setLeft(Node left) {
        this.left = left;
    }

    public Node getRight() {
        return right;
    }

    public void setRight(Node right) {
        this.right = right;
    }

    public int getValor() {
        return valor;
    }

}
