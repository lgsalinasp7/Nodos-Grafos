package model;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class GrafoPanel extends JPanel {

    // Lista de nodos que guardará las posiciones y etiquetas
    private List<Nodo> nodos = new ArrayList<>();
    private int contador = 1; // Para numerar los nodos

    public GrafoPanel() {
        setBackground(Color.WHITE);

        // Detectar clics en el panel
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();

                // Crear un nuevo nodo en la posición clicada
                nodos.add(new Nodo(x, y, "N" + contador));
                contador++;

                // Redibujar el panel
                repaint();
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Dibujar todos los nodos
        for (Nodo nodo : nodos) {
            dibujarNodo(g2, nodo.x, nodo.y, nodo.label);
        }
    }

    private void dibujarNodo(Graphics2D g2, int x, int y, String label) {
        int radio = 30;

        // Dibujar círculo
        g2.setColor(Color.BLUE);
        g2.fillOval(x - radio / 2, y - radio / 2, radio, radio);

        // Borde
        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke(2));
        g2.drawOval(x - radio / 2, y - radio / 2, radio, radio);

        // Texto centrado
        FontMetrics fm = g2.getFontMetrics();
        int textWidth = fm.stringWidth(label);
        int textHeight = fm.getAscent();
        g2.drawString(label, x - textWidth / 2, y + textHeight / 4);
    }

    // Clase para representar un nodo
    private static class Nodo {
        int x, y;
        String label;

        Nodo(int x, int y, String label) {
            this.x = x;
            this.y = y;
            this.label = label;
        }
    }

    // Ejecución
    public static void main(String[] args) {
        JFrame frame = new JFrame("Dibujar Nodos con Clic");
        GrafoPanel panel = new GrafoPanel();
        frame.add(panel);
        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
