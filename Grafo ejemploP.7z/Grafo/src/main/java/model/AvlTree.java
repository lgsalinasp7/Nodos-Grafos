package model;


public class AvlTree {

    private Node root;
    private int countNodes;
    private int balance;
    private int altDer;
    private int altIzq;
    private String rotacion;

    public AvlTree() {
        this.root = null;
        this.countNodes = 0;
        this.balance = 0;
        this.altDer = 0;
        this.altIzq = 0;
        this.rotacion = "No rota";
    }

    public int getBalance() {
        return balance;
    }

    public int getAltDer() {
        return altDer;
    }

    public int getAltIzq() {
        return altIzq;
    }

    public String getRotacion() {
        return rotacion;
    }

    public int getCountNodes() {
        return countNodes;
    }    

    public Node getRoot() {
        return root;
    }

    private int altura(Node node) {
        return node == null ? 0 : 1 + Math.max(altura(node.getLeft()), altura(node.getRight()));
    }

    private int factorEquilibrio(Node node) {
        this.altDer = altura(node.getRight());
        this.altIzq = altura(node.getLeft());
        return node == null ? 0 : this.altDer - this.altIzq;
    }


    private Node rotarDerecha(Node y) {
        Node x = y.getLeft();
        Node t2 = x.getRight();
        x.setRight(y);
        y.setLeft(t2);
        return x;
    }

    private Node rotarIzquierda(Node x) {
        Node y = x.getRight();
        Node t2 = y.getLeft();
        y.setLeft(x);
        x.setRight(t2);
        return y;
    }


    public void insert(int valor) {
        this.root = insertRec(valor, this.root);
    }

    private Node insertRec(int valor, Node node) {
      
        if (node == null) {
            this.countNodes += 1;
            return new Node(valor);
        }
        if (valor < node.getValor()) {
            node.setLeft(insertRec(valor, node.getLeft()));
        } else {
            if (valor > node.getValor()) {
                node.setRight(insertRec(valor, node.getRight()));
            }
       
        }
        return balancear(valor, node);
    }

    private Node balancear(int valor, Node node) {

        this.balance = factorEquilibrio(node);
        
        if(this.balance == -1 || this.balance == 0 || this.balance == 1){
            this.rotacion = "No rota";
        }

        if (this.balance < -1 && valor < node.getLeft().getValor()) {
            this.rotacion = "Rot.Der";
            return rotarDerecha(node);
        }

        if (this.balance > 1 && valor > node.getRight().getValor()) {
            this.rotacion = "Rot.Izq";
            return rotarIzquierda(node);
        }

        if (this.balance < -1 && valor > node.getLeft().getValor()) {
            this.rotacion = "Rot.Izq - Rot.Der";
            node.setLeft(rotarIzquierda(node.getLeft()));
            return rotarDerecha(node);
        }

        if (this.balance > 1 && valor < node.getRight().getValor()) {
            this.rotacion = "Rot.Der - Rot.Izq";
            node.setRight(rotarDerecha(node.getRight()));
            return rotarIzquierda(node);
        }
        
        return node;

    }



}
