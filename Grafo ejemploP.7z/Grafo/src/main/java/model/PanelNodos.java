package model;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class PanelNodos extends JPanel {

    private static class Nodo {
        int x, y;
        String valor;

        Nodo(int x, int y, String valor) {
            this.x = x;
            this.y = y;
            this.valor = valor;
        }
    }

    private java.util.List<Nodo> nodos = new ArrayList<>();

    public PanelNodos() {
        setBackground(Color.WHITE);

        // Listener para clics en el panel
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String valor = JOptionPane.showInputDialog(
                        PanelNodos.this,
                        "Ingrese el valor del nodo:",
                        "Crear Nodo",
                        JOptionPane.PLAIN_MESSAGE
                );

                if (valor != null && !valor.trim().isEmpty()) {
                    nodos.add(new Nodo(e.getX(), e.getY(), valor.trim()));
                    repaint();
                }
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        for (Nodo nodo : nodos) {
            // Ajustar tamaño del círculo según la longitud del texto
            FontMetrics fm = g2.getFontMetrics();
            int anchoTexto = fm.stringWidth(nodo.valor);
            int diametro = Math.max(40, anchoTexto + 20);

            // Dibujar círculo
            g2.setColor(Color.CYAN);
            g2.fillOval(nodo.x - diametro / 2, nodo.y - diametro / 2, diametro, diametro);

            g2.setColor(Color.BLACK);
            g2.drawOval(nodo.x - diametro / 2, nodo.y - diametro / 2, diametro, diametro);

            // Dibujar texto centrado
            int xTexto = nodo.x - anchoTexto / 2;
            int yTexto = nodo.y + fm.getAscent() / 2 - 2;
            g2.drawString(nodo.valor, xTexto, yTexto);
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Crear nodos con clic");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.add(new PanelNodos());
        frame.setVisible(true);
    }
}

