package model;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JPanel;

public class DibujarNodo extends JPanel {

    private Node root;
    private Font fuenteNegrita;

    public DibujarNodo(Node root) {
        this.root = root;
        this.fuenteNegrita = new Font("Consolas", Font.BOLD, 12);

    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (this.root != null) {
            draw(g, this.root, getWidth() / 2, 30, getWidth() / 4);
        }

    }

    private void draw(Graphics g, Node node, int x, int y, int offset) {

        if (node == null) {
            return;
        }

        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        // Texto y medidas
        String texto = String.valueOf(node.getValor());
        FontMetrics fm = g2.getFontMetrics();
        int anchoTexto = fm.stringWidth(texto);
        int altoTexto = fm.getAscent();

        // Cálculo del radio según el texto (agregamos padding)
        int padding = 8; // margen interno
        int radio = Math.max(anchoTexto, altoTexto) / 2 + padding;

        g.setColor(Color.red);
        if (node.getLeft() != null) {
            g.drawLine(x, y, x - offset, y + 50);
        }

        if (node.getRight() != null) {
            g.drawLine(x, y, x + offset, y + 50);
        }

        g.setColor(Color.BLUE);
        g.fillOval(x - radio, y - radio, radio * 2, radio * 2);

        g2.setColor(Color.white);
        g2.setFont(fuenteNegrita);
        g2.drawString(texto, x - (anchoTexto / 2), y + (altoTexto / 4));

        g.setColor(Color.red);
        if (node.getLeft() != null) {
            
            draw(g, node.getLeft(), x - offset, y + 50, offset / 2);
        }

        if (node.getRight() != null) {
            draw(g, node.getRight(), x + offset, y + 50, offset / 2);
        }

    }
}
