package app;

import controller.ViewBstTreeController;
import model.AvlTree;
import view.Vista;

public class Principal {

    public static void main(String[] args) {
        AvlTree model = new AvlTree();
        Vista view = new Vista();
        ViewBstTreeController controller = new ViewBstTreeController(model, view);
        controller.startView();

    }
}
