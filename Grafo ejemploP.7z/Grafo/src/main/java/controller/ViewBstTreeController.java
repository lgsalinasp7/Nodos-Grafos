package controller;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.AvlTree;
import model.DibujarNodo;
import view.Vista;

public class ViewBstTreeController implements ActionListener {

    private AvlTree model;
    private Vista view;
    private DibujarNodo grafo;

    public ViewBstTreeController(AvlTree model, Vista view) {
        this.model = model;
        this.view = view;
        this.view.getBtnAdd().addActionListener(e -> {
            addNode();
        });

    }
    public void startView() {

        this.view.setTitle("Vista Grafo");
        this.view.setSize(800, 600);
        this.view.setVisible(true);
        this.view.setLocationRelativeTo(null);

    }

    private void addNode() {
        this.model.insert(Integer.parseInt(this.view.getTxtInsert().getText()));
        this.view.getTxtInsert().setText("");
        this.view.getTxtInsert().requestFocus();
        actualizarPanel();
    }

    private void actualizarPanel() {

        this.grafo = new DibujarNodo(this.model.getRoot());
        this.view.getGrafo().removeAll();
        this.view.getGrafo().setLayout(new BorderLayout());
        this.view.getGrafo().add(this.grafo, BorderLayout.CENTER);
        this.view.getGrafo().revalidate();
        this.view.getGrafo().repaint();

    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }

}
